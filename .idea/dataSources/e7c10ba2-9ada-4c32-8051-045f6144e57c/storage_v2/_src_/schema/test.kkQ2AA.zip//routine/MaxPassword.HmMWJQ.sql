CREATE PROCEDURE MaxPassword(OUT Max INT)
  BEGIN
  SELECT max(password) into Max from users;
END;

