CREATE PROCEDURE UsersCount(OUT Count INT)
  BEGIN
    SELECT count(*) into count from users2;
  END;

